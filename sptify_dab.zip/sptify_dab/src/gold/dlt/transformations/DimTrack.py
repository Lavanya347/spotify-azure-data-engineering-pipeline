import dlt
#declarative pipeline?


@dlt.table()
def DimTrackStg():
    df = spark.readStream.table("spotify_catalog.silver.DimTrack")
    return df   

dlt.create_streaming_table("dimtrack")

dlt.create_auto_cdc_flow(
    target="dimtrack",
    source="DimTrackStg",
    keys=["track_id"],
    sequence_by="updated_at",
    stored_as_scd_type=2,
    track_history_except_column_list= None,
    name= None,
    once= False
)